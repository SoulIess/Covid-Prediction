Python Version: 3.9.12
Libraries Used:
    *pandas
    *numpy
    *matplotlib.pyplot
    *sklearn
        **preprocessing 
        **GridSearchCV
        **make_scorer
        **accuracy_score
        **f1_score
        **train_test_split
        **KNeighborsClassifier
        **SVC
    *csv
